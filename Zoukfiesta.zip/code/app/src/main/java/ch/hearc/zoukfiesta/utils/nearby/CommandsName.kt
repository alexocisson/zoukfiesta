package ch.hearc.zoukfiesta.utils.nearby

enum class CommandsName {
    SKIP,
    WHAT,
    MUSICS,
    ADD,
    PLAYLIST,
    KICK,
    AVAILABLE
}